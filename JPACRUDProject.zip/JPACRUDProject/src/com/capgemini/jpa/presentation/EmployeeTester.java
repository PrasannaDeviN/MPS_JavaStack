package com.capgemini.jpa.presentation;

import java.util.GregorianCalendar;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.service.EmployeeServiceImpl;
import com.capgemini.jpa.service.IEmployeeService;

public class EmployeeTester {
	private static IEmployeeService employeeService=
								new EmployeeServiceImpl();
	
	public static void main(String[] args) {
		Employee employee=
		    new Employee(7000,"Clarke",new GregorianCalendar(2016,10,15),"Manager",65750.0,10);
		
		addNewEmployee(employee);
	}

	private static void addNewEmployee(Employee employee) {
		try {
			employeeService.addNewEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}

}
